# 🕵️‍♂️ Black Ops – Real-Time Threat Hunter for Web Servers

**Black Ops** is a Python-based tool that monitors web server logs for suspicious behavior (like SQL injection scans, brute-force attempts, or mass 404s) and auto-blocks malicious IPs in real time using `iptables`.

## 🚀 Features
- Real-time monitoring of Nginx/Apache logs
- Auto-blocking of IPs with customizable thresholds
- Detects SQLmap, Nikto, and similar tools
- Easy configuration and extension

## 📦 Installation
```bash
git clone https://github.com/yourusername/black-ops.git
cd black-ops
pip install .
```

## ⚙️ Usage
```bash
sudo python3 scripts/run_blackops.py
```

## 🔧 Configuration
Edit `blackops/config.py` to customize:
- Log file path
- Block threshold
- Regex patterns for suspicious activity

## 📜 License
MIT License

---

**Made with 🔥 by Rafiq Nur**
