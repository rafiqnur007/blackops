from blackops.core import monitor

if __name__ == "__main__":
    monitor()
